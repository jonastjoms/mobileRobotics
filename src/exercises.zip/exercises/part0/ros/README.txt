To run Gazebo:
> roslaunch exercises gazebo.launch

To run hello_world on the robot:
> roslaunch exercises hello_world.launch

To run RViz:
> roslaunch exercises rviz.launch